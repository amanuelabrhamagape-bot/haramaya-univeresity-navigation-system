// ===== NAVIGATION MENU TOGGLE =====
document.addEventListener('DOMContentLoaded', function() {
    const hamburger = document.querySelector('.hamburger');
    const navMenu = document.querySelector('.nav-menu');

    if (hamburger) {
        hamburger.addEventListener('click', function() {
            navMenu.classList.toggle('active');
            
            // Animate hamburger
            const spans = hamburger.querySelectorAll('span');
            if (navMenu.classList.contains('active')) {
                spans[0].style.transform = 'rotate(45deg) translate(8px, 8px)';
                spans[1].style.opacity = '0';
                spans[2].style.transform = 'rotate(-45deg) translate(7px, -7px)';
            } else {
                spans[0].style.transform = 'none';
                spans[1].style.opacity = '1';
                spans[2].style.transform = 'none';
            }
        });

        // Close menu when clicking on a link
        const navLinks = document.querySelectorAll('.nav-menu a');
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                navMenu.classList.remove('active');
                const spans = hamburger.querySelectorAll('span');
                spans[0].style.transform = 'none';
                spans[1].style.opacity = '1';
                spans[2].style.transform = 'none';
            });
        });
    }
});

// ===== SMOOTH SCROLLING =====
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// ===== CAMPUS LOCATIONS DATA =====
const campusLocations = {
    library: {
        name: 'Library',
        icon: 'fa-book',
        color: '#1976d2',
        description: 'The campus library is a state-of-the-art facility offering extensive resources for students and faculty.',
        details: {
            location: 'North Campus, Building A',
            hours: 'Monday-Friday: 8:00 AM - 10:00 PM<br>Saturday-Sunday: 10:00 AM - 8:00 PM',
            phone: '(555) 123-4501',
            email: 'library@campus.edu'
        },
        features: [
            'Over 100,000 books and journals',
            'Computer labs with latest software',
            'Private study rooms',
            'Group collaboration spaces',
            'Research assistance desk',
            'Printing and scanning services',
            'Quiet zones for focused study',
            'Coffee shop on ground floor'
        ],
        services: [
            'Book lending and returns',
            'Research consultation',
            'Interlibrary loan',
            'Digital resources access',
            'Study room reservations',
            'Workshops and training'
        ]
    },
    cafeteria: {
        name: 'Cafeteria',
        icon: 'fa-utensils',
        color: '#f57c00',
        description: 'Our main dining facility offers a variety of healthy and delicious meal options to suit all dietary preferences.',
        details: {
            location: 'East Campus, Building B',
            hours: 'Monday-Sunday: 7:00 AM - 9:00 PM<br>Breakfast: 7:00-10:00 AM<br>Lunch: 11:30 AM-2:30 PM<br>Dinner: 5:00-8:00 PM',
            phone: '(555) 123-4502',
            email: 'dining@campus.edu'
        },
        features: [
            'Multiple food stations',
            'Vegetarian and vegan options',
            'Halal and kosher meals available',
            'Salad and fresh fruit bar',
            'International cuisine',
            'Grab-and-go options',
            'Indoor and outdoor seating',
            'Free WiFi'
        ],
        services: [
            'Meal plans available',
            'Catering for events',
            'Nutritional information provided',
            'Special dietary accommodations',
            'Mobile ordering app',
            'Student discounts'
        ]
    },
    admin: {
        name: 'Admin Building',
        icon: 'fa-building',
        color: '#7b1fa2',
        description: 'The administrative hub of the campus, housing key offices for student services and university operations.',
        details: {
            location: 'Central Campus, Main Building',
            hours: 'Monday-Friday: 9:00 AM - 5:00 PM<br>Closed on weekends and holidays',
            phone: '(555) 123-4500',
            email: 'admin@campus.edu'
        },
        features: [
            'Registrar\'s office',
            'Financial aid office',
            'Admissions office',
            'Student accounts',
            'Academic advising',
            'Career services',
            'International student office',
            'Disability services'
        ],
        services: [
            'Course registration',
            'Transcript requests',
            'Financial aid applications',
            'Tuition payment',
            'Academic counseling',
            'Career guidance',
            'Visa and immigration support',
            'Accommodation requests'
        ]
    },
    dorms: {
        name: 'Dormitories',
        icon: 'fa-home',
        color: '#388e3c',
        description: 'Modern student housing facilities providing a safe, comfortable, and community-oriented living environment.',
        details: {
            location: 'West Campus, Residential Area',
            hours: '24/7 Access for Residents<br>Front Desk: 24/7<br>Maintenance: 8:00 AM - 5:00 PM',
            phone: '(555) 123-4503',
            email: 'housing@campus.edu'
        },
        features: [
            'Single and double occupancy rooms',
            'Furnished rooms with WiFi',
            'Common lounges and kitchens',
            'Laundry facilities',
            'Study rooms',
            'Recreation areas',
            '24/7 security',
            'On-site resident advisors'
        ],
        services: [
            'Housing applications',
            'Room assignments',
            'Maintenance requests',
            'Package delivery',
            'Community events',
            'Residential life programs',
            'Emergency assistance',
            'Move-in/move-out support'
        ]
    },
    labs: {
        name: 'Science Labs',
        icon: 'fa-flask',
        color: '#c62828',
        description: 'Cutting-edge research and teaching laboratories equipped with modern scientific instruments and technology.',
        details: {
            location: 'South Campus, Science Complex',
            hours: 'Monday-Friday: 8:00 AM - 8:00 PM<br>Saturday: 10:00 AM - 4:00 PM<br>Closed on Sundays',
            phone: '(555) 123-4504',
            email: 'labs@campus.edu'
        },
        features: [
            'Biology laboratories',
            'Chemistry laboratories',
            'Physics laboratories',
            'Computer science labs',
            'Research equipment',
            'Safety equipment provided',
            'Specialized instruments',
            'Collaborative workspaces'
        ],
        services: [
            'Lab course instruction',
            'Research opportunities',
            'Equipment training',
            'Safety orientations',
            'Lab reservations',
            'Technical support',
            'Research assistance',
            'Project collaboration'
        ]
    }
};

// ===== UTILITY FUNCTIONS =====
function getLocationData(locationId) {
    return campusLocations[locationId] || null;
}

function formatLocationDetails(location) {
    if (!location) return '';
    
    let html = `
        <div class="location-full-details">
            <p class="location-description">${location.description}</p>
            
            <h3><i class="fas fa-info-circle"></i> Details</h3>
            <div class="detail-item">
                <strong><i class="fas fa-map-marker-alt"></i> Location:</strong>
                <p>${location.details.location}</p>
            </div>
            <div class="detail-item">
                <strong><i class="fas fa-clock"></i> Hours:</strong>
                <p>${location.details.hours}</p>
            </div>
            <div class="detail-item">
                <strong><i class="fas fa-phone"></i> Phone:</strong>
                <p>${location.details.phone}</p>
            </div>
            <div class="detail-item">
                <strong><i class="fas fa-envelope"></i> Email:</strong>
                <p>${location.details.email}</p>
            </div>
            
            <h3><i class="fas fa-star"></i> Features</h3>
            <ul>
                ${location.features.map(feature => `<li>${feature}</li>`).join('')}
            </ul>
            
            <h3><i class="fas fa-concierge-bell"></i> Services</h3>
            <ul>
                ${location.services.map(service => `<li>${service}</li>`).join('')}
            </ul>
        </div>
    `;
    
    return html;
}

// ===== SCROLL ANIMATIONS =====
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe elements with animation classes
document.addEventListener('DOMContentLoaded', function() {
    const animatedElements = document.querySelectorAll('.feature-card, .location-card, .location-card-detailed');
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
});

// ===== EXPORT FOR OTHER MODULES =====
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { campusLocations, getLocationData, formatLocationDetails };
}
