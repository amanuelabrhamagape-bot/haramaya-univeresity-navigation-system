// ===== CONTACT FORM VALIDATION =====
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contactForm');
    const successMessage = document.getElementById('successMessage');

    if (contactForm) {
        // Form field elements
        const nameInput = document.getElementById('name');
        const emailInput = document.getElementById('email');
        const messageInput = document.getElementById('message');

        // Error message elements
        const nameError = document.getElementById('nameError');
        const emailError = document.getElementById('emailError');
        const messageError = document.getElementById('messageError');

        // Real-time validation
        nameInput.addEventListener('blur', () => validateName());
        emailInput.addEventListener('blur', () => validateEmail());
        messageInput.addEventListener('blur', () => validateMessage());

        // Clear error on input
        nameInput.addEventListener('input', () => clearError(nameInput, nameError));
        emailInput.addEventListener('input', () => clearError(emailInput, emailError));
        messageInput.addEventListener('input', () => clearError(messageInput, messageError));

        // Form submission
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();

            // Validate all fields
            const isNameValid = validateName();
            const isEmailValid = validateEmail();
            const isMessageValid = validateMessage();

            if (isNameValid && isEmailValid && isMessageValid) {
                // Simulate form submission
                submitForm();
            }
        });

        // Validation functions
        function validateName() {
            const name = nameInput.value.trim();
            
            if (name === '') {
                showError(nameInput, nameError, 'Name is required');
                return false;
            } else if (name.length < 2) {
                showError(nameInput, nameError, 'Name must be at least 2 characters');
                return false;
            } else if (!/^[a-zA-Z\s]+$/.test(name)) {
                showError(nameInput, nameError, 'Name can only contain letters and spaces');
                return false;
            } else {
                clearError(nameInput, nameError);
                return true;
            }
        }

        function validateEmail() {
            const email = emailInput.value.trim();
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            
            if (email === '') {
                showError(emailInput, emailError, 'Email is required');
                return false;
            } else if (!emailRegex.test(email)) {
                showError(emailInput, emailError, 'Please enter a valid email address');
                return false;
            } else {
                clearError(emailInput, emailError);
                return true;
            }
        }

        function validateMessage() {
            const message = messageInput.value.trim();
            
            if (message === '') {
                showError(messageInput, messageError, 'Message is required');
                return false;
            } else if (message.length < 10) {
                showError(messageInput, messageError, 'Message must be at least 10 characters');
                return false;
            } else if (message.length > 1000) {
                showError(messageInput, messageError, 'Message must not exceed 1000 characters');
                return false;
            } else {
                clearError(messageInput, messageError);
                return true;
            }
        }

        function showError(input, errorElement, message) {
            input.style.borderColor = '#ef4444';
            errorElement.textContent = message;
            errorElement.style.display = 'block';
            
            // Add shake animation
            input.style.animation = 'shake 0.3s';
            setTimeout(() => {
                input.style.animation = '';
            }, 300);
        }

        function clearError(input, errorElement) {
            input.style.borderColor = '#e5e7eb';
            errorElement.textContent = '';
            errorElement.style.display = 'none';
        }

        function submitForm() {
            // Show loading state
            const submitButton = contactForm.querySelector('button[type="submit"]');
            const originalText = submitButton.innerHTML;
            submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
            submitButton.disabled = true;

            // Simulate API call
            setTimeout(() => {
                // Hide form and show success message
                contactForm.style.display = 'none';
                successMessage.style.display = 'block';
                
                // Animate success message
                successMessage.style.opacity = '0';
                successMessage.style.transform = 'translateY(20px)';
                setTimeout(() => {
                    successMessage.style.transition = 'all 0.5s ease';
                    successMessage.style.opacity = '1';
                    successMessage.style.transform = 'translateY(0)';
                }, 50);

                // Reset form after 5 seconds
                setTimeout(() => {
                    contactForm.reset();
                    contactForm.style.display = 'block';
                    successMessage.style.display = 'none';
                    submitButton.innerHTML = originalText;
                    submitButton.disabled = false;
                }, 5000);
            }, 1500);
        }
    }
});

// ===== SHAKE ANIMATION =====
const style = document.createElement('style');
style.textContent = `
    @keyframes shake {
        0%, 100% { transform: translateX(0); }
        25% { transform: translateX(-10px); }
        75% { transform: translateX(10px); }
    }
`;
document.head.appendChild(style);

// ===== CHARACTER COUNTER FOR MESSAGE =====
document.addEventListener('DOMContentLoaded', function() {
    const messageInput = document.getElementById('message');
    
    if (messageInput) {
        const counterDiv = document.createElement('div');
        counterDiv.className = 'character-counter';
        counterDiv.style.cssText = `
            text-align: right;
            font-size: 0.9rem;
            color: #6b7280;
            margin-top: 0.5rem;
        `;
        
        messageInput.parentElement.appendChild(counterDiv);
        
        messageInput.addEventListener('input', function() {
            const length = this.value.length;
            const maxLength = 1000;
            counterDiv.textContent = `${length} / ${maxLength} characters`;
            
            if (length > maxLength * 0.9) {
                counterDiv.style.color = '#ef4444';
            } else if (length > maxLength * 0.7) {
                counterDiv.style.color = '#f59e0b';
            } else {
                counterDiv.style.color = '#6b7280';
            }
        });
        
        // Initialize counter
        messageInput.dispatchEvent(new Event('input'));
    }
});

// ===== FORM FIELD ANIMATIONS =====
document.addEventListener('DOMContentLoaded', function() {
    const formInputs = document.querySelectorAll('.form-group input, .form-group textarea, .form-group select');
    
    formInputs.forEach(input => {
        // Add focus effect
        input.addEventListener('focus', function() {
            this.parentElement.style.transform = 'translateY(-2px)';
            this.parentElement.style.transition = 'transform 0.3s ease';
        });
        
        input.addEventListener('blur', function() {
            this.parentElement.style.transform = 'translateY(0)';
        });
        
        // Add filled class when input has value
        input.addEventListener('input', function() {
            if (this.value.trim() !== '') {
                this.classList.add('filled');
            } else {
                this.classList.remove('filled');
            }
        });
    });
});

// ===== AUTO-SAVE DRAFT (LOCAL STORAGE) =====
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contactForm');
    
    if (contactForm) {
        const formFields = ['name', 'email', 'subject', 'message'];
        
        // Load saved draft
        formFields.forEach(field => {
            const savedValue = localStorage.getItem(`contact_${field}`);
            if (savedValue) {
                const input = document.getElementById(field);
                if (input) {
                    input.value = savedValue;
                    input.classList.add('filled');
                }
            }
        });
        
        // Save draft on input
        formFields.forEach(field => {
            const input = document.getElementById(field);
            if (input) {
                input.addEventListener('input', function() {
                    localStorage.setItem(`contact_${field}`, this.value);
                });
            }
        });
        
        // Clear draft on successful submission
        contactForm.addEventListener('submit', function() {
            setTimeout(() => {
                formFields.forEach(field => {
                    localStorage.removeItem(`contact_${field}`);
                });
            }, 2000);
        });
        
        // Add clear draft button
        if (localStorage.getItem('contact_name') || localStorage.getItem('contact_email') || 
            localStorage.getItem('contact_subject') || localStorage.getItem('contact_message')) {
            
            const clearButton = document.createElement('button');
            clearButton.type = 'button';
            clearButton.className = 'btn btn-secondary btn-full';
            clearButton.style.marginTop = '1rem';
            clearButton.innerHTML = '<i class="fas fa-trash"></i> Clear Draft';
            clearButton.addEventListener('click', function() {
                if (confirm('Are you sure you want to clear the saved draft?')) {
                    formFields.forEach(field => {
                        localStorage.removeItem(`contact_${field}`);
                        const input = document.getElementById(field);
                        if (input) {
                            input.value = '';
                            input.classList.remove('filled');
                        }
                    });
                    this.remove();
                }
            });
            
            contactForm.appendChild(clearButton);
        }
    }
});
