// ===== SEARCH FUNCTIONALITY =====
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('locationSearch');
    const locationsGrid = document.getElementById('locationsGrid');
    const noResults = document.getElementById('noResults');
    const locationCards = document.querySelectorAll('.location-card-detailed');

    if (searchInput && locationsGrid) {
        searchInput.addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase().trim();
            
            let visibleCount = 0;

            locationCards.forEach(card => {
                const locationName = card.querySelector('h3').textContent.toLowerCase();
                const locationDescription = card.querySelector('.location-description').textContent.toLowerCase();
                const locationInfo = card.querySelector('.location-info').textContent.toLowerCase();
                
                // Search in name, description, and info
                const matches = locationName.includes(searchTerm) || 
                               locationDescription.includes(searchTerm) ||
                               locationInfo.includes(searchTerm);

                if (matches || searchTerm === '') {
                    card.style.display = 'block';
                    // Add animation
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transform = 'translateY(0)';
                    }, 50);
                    visibleCount++;
                } else {
                    card.style.opacity = '0';
                    card.style.transform = 'translateY(20px)';
                    setTimeout(() => {
                        card.style.display = 'none';
                    }, 300);
                }
            });

            // Show/hide no results message
            if (visibleCount === 0 && searchTerm !== '') {
                noResults.style.display = 'block';
                locationsGrid.style.display = 'none';
            } else {
                noResults.style.display = 'none';
                locationsGrid.style.display = 'grid';
            }
        });

        // Add search icon animation
        searchInput.addEventListener('focus', function() {
            this.parentElement.style.transform = 'scale(1.02)';
            this.parentElement.style.transition = 'transform 0.3s ease';
        });

        searchInput.addEventListener('blur', function() {
            this.parentElement.style.transform = 'scale(1)';
        });

        // Clear search on Escape key
        searchInput.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                this.value = '';
                this.dispatchEvent(new Event('input'));
                this.blur();
            }
        });
    }
});

// ===== FILTER FUNCTIONALITY =====
document.addEventListener('DOMContentLoaded', function() {
    // Add filter buttons dynamically
    const searchSection = document.querySelector('.search-section .container');
    
    if (searchSection) {
        const filterContainer = document.createElement('div');
        filterContainer.className = 'filter-container';
        filterContainer.innerHTML = `
            <div class="filter-buttons">
                <button class="filter-btn active" data-filter="all">
                    <i class="fas fa-th"></i> All Locations
                </button>
                <button class="filter-btn" data-filter="academic">
                    <i class="fas fa-graduation-cap"></i> Academic
                </button>
                <button class="filter-btn" data-filter="services">
                    <i class="fas fa-concierge-bell"></i> Services
                </button>
                <button class="filter-btn" data-filter="facilities">
                    <i class="fas fa-building"></i> Facilities
                </button>
            </div>
        `;

        // Add styles for filter buttons
        const style = document.createElement('style');
        style.textContent = `
            .filter-container {
                margin-top: 2rem;
            }
            .filter-buttons {
                display: flex;
                justify-content: center;
                gap: 1rem;
                flex-wrap: wrap;
            }
            .filter-btn {
                padding: 10px 20px;
                border: 2px solid #e5e7eb;
                background: white;
                border-radius: 25px;
                cursor: pointer;
                transition: all 0.3s ease;
                font-weight: 600;
                color: #374151;
            }
            .filter-btn:hover {
                border-color: #2563eb;
                color: #2563eb;
                transform: translateY(-2px);
            }
            .filter-btn.active {
                background: linear-gradient(135deg, #2563eb, #7c3aed);
                color: white;
                border-color: transparent;
            }
            .filter-btn i {
                margin-right: 5px;
            }
            @media (max-width: 768px) {
                .filter-buttons {
                    flex-direction: column;
                }
                .filter-btn {
                    width: 100%;
                }
            }
        `;
        document.head.appendChild(style);

        searchSection.appendChild(filterContainer);

        // Add category data to cards
        const categoryMap = {
            'library': 'academic',
            'labs': 'academic',
            'cafeteria': 'services',
            'admin': 'services',
            'dorms': 'facilities'
        };

        const locationCards = document.querySelectorAll('.location-card-detailed');
        locationCards.forEach(card => {
            const location = card.getAttribute('data-location');
            const category = categoryMap[location] || 'facilities';
            card.setAttribute('data-category', category);
        });

        // Filter functionality
        const filterButtons = document.querySelectorAll('.filter-btn');
        filterButtons.forEach(button => {
            button.addEventListener('click', function() {
                const filter = this.getAttribute('data-filter');
                
                // Update active button
                filterButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');

                // Filter cards
                locationCards.forEach(card => {
                    const category = card.getAttribute('data-category');
                    
                    if (filter === 'all' || category === filter) {
                        card.style.display = 'block';
                        setTimeout(() => {
                            card.style.opacity = '1';
                            card.style.transform = 'translateY(0)';
                        }, 50);
                    } else {
                        card.style.opacity = '0';
                        card.style.transform = 'translateY(20px)';
                        setTimeout(() => {
                            card.style.display = 'none';
                        }, 300);
                    }
                });
            });
        });
    }
});

// ===== SEARCH SUGGESTIONS =====
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('locationSearch');
    
    if (searchInput) {
        const suggestions = [
            'Library',
            'Cafeteria',
            'Admin Building',
            'Dormitories',
            'Science Labs',
            'Study rooms',
            'Food services',
            'Student services',
            'Housing',
            'Research facilities'
        ];

        // Create suggestions dropdown
        const suggestionsDiv = document.createElement('div');
        suggestionsDiv.className = 'search-suggestions';
        suggestionsDiv.style.cssText = `
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: white;
            border: 2px solid #e5e7eb;
            border-top: none;
            border-radius: 0 0 25px 25px;
            max-height: 300px;
            overflow-y: auto;
            display: none;
            z-index: 100;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        `;

        searchInput.parentElement.style.position = 'relative';
        searchInput.parentElement.appendChild(suggestionsDiv);

        searchInput.addEventListener('input', function(e) {
            const value = e.target.value.toLowerCase();
            
            if (value.length > 0) {
                const filtered = suggestions.filter(s => 
                    s.toLowerCase().includes(value)
                );

                if (filtered.length > 0) {
                    suggestionsDiv.innerHTML = filtered.map(s => `
                        <div class="suggestion-item" style="
                            padding: 12px 20px;
                            cursor: pointer;
                            transition: background 0.2s ease;
                        ">
                            <i class="fas fa-search" style="margin-right: 10px; color: #9ca3af;"></i>
                            ${s}
                        </div>
                    `).join('');
                    suggestionsDiv.style.display = 'block';

                    // Add click handlers
                    document.querySelectorAll('.suggestion-item').forEach(item => {
                        item.addEventListener('mouseenter', function() {
                            this.style.background = '#f3f4f6';
                        });
                        item.addEventListener('mouseleave', function() {
                            this.style.background = 'white';
                        });
                        item.addEventListener('click', function() {
                            searchInput.value = this.textContent.trim();
                            searchInput.dispatchEvent(new Event('input'));
                            suggestionsDiv.style.display = 'none';
                        });
                    });
                } else {
                    suggestionsDiv.style.display = 'none';
                }
            } else {
                suggestionsDiv.style.display = 'none';
            }
        });

        // Close suggestions when clicking outside
        document.addEventListener('click', function(e) {
            if (!searchInput.parentElement.contains(e.target)) {
                suggestionsDiv.style.display = 'none';
            }
        });
    }
});
