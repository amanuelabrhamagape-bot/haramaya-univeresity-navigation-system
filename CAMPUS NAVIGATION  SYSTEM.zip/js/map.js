// ===== INTERACTIVE MAP FUNCTIONALITY =====
document.addEventListener('DOMContentLoaded', function() {
    const buildingMarkers = document.querySelectorAll('.building-marker');
    const buildingDetails = document.getElementById('buildingDetails');
    const buildingName = document.getElementById('buildingName');
    const detailsContent = document.getElementById('detailsContent');
    const closeBtn = document.getElementById('closeDetails');

    // Check if there's a location parameter in URL
    const urlParams = new URLSearchParams(window.location.search);
    const locationParam = urlParams.get('location');
    
    if (locationParam) {
        // Automatically show details for the specified location
        const targetBuilding = document.querySelector(`[data-building="${locationParam}"]`);
        if (targetBuilding) {
            setTimeout(() => {
                showBuildingDetails(locationParam);
                highlightBuilding(targetBuilding);
            }, 500);
        }
    }

    // Add click event to each building marker
    buildingMarkers.forEach(marker => {
        marker.addEventListener('click', function() {
            const building = this.getAttribute('data-building');
            showBuildingDetails(building);
            highlightBuilding(this);
        });

        // Add hover effect
        marker.addEventListener('mouseenter', function() {
            this.style.cursor = 'pointer';
            this.style.filter = 'brightness(1.1)';
        });

        marker.addEventListener('mouseleave', function() {
            if (!this.classList.contains('active')) {
                this.style.filter = 'none';
            }
        });
    });

    // Close button functionality
    if (closeBtn) {
        closeBtn.addEventListener('click', function() {
            buildingDetails.style.display = 'none';
            buildingMarkers.forEach(marker => {
                marker.classList.remove('active');
                marker.style.filter = 'none';
            });
        });
    }

    function showBuildingDetails(buildingId) {
        const location = campusLocations[buildingId];
        
        if (location) {
            buildingName.innerHTML = `<i class="fas ${location.icon}"></i> ${location.name}`;
            detailsContent.innerHTML = formatLocationDetails(location);
            buildingDetails.style.display = 'block';
            
            // Smooth scroll to details on mobile
            if (window.innerWidth <= 768) {
                buildingDetails.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
        }
    }

    function highlightBuilding(marker) {
        // Remove active class from all markers
        buildingMarkers.forEach(m => {
            m.classList.remove('active');
            m.style.filter = 'none';
        });
        
        // Add active class to clicked marker
        marker.classList.add('active');
        marker.style.filter = 'brightness(1.2)';
    }

    // Make map responsive
    window.addEventListener('resize', function() {
        if (window.innerWidth <= 768) {
            const mapContainer = document.querySelector('.map-container');
            if (mapContainer) {
                mapContainer.style.gridTemplateColumns = '1fr';
            }
        }
    });
});

// ===== MAP ZOOM FUNCTIONALITY =====
document.addEventListener('DOMContentLoaded', function() {
    const campusMap = document.querySelector('.campus-map svg');
    
    if (campusMap) {
        let scale = 1;
        const scaleStep = 0.1;
        const maxScale = 2;
        const minScale = 0.5;

        // Add zoom controls
        const zoomControls = document.createElement('div');
        zoomControls.className = 'zoom-controls';
        zoomControls.innerHTML = `
            <button id="zoomIn" class="zoom-btn" title="Zoom In">
                <i class="fas fa-plus"></i>
            </button>
            <button id="zoomOut" class="zoom-btn" title="Zoom Out">
                <i class="fas fa-minus"></i>
            </button>
            <button id="zoomReset" class="zoom-btn" title="Reset Zoom">
                <i class="fas fa-undo"></i>
            </button>
        `;

        // Add styles for zoom controls
        const style = document.createElement('style');
        style.textContent = `
            .zoom-controls {
                position: absolute;
                top: 20px;
                right: 20px;
                display: flex;
                flex-direction: column;
                gap: 10px;
                z-index: 10;
            }
            .zoom-btn {
                width: 40px;
                height: 40px;
                background: white;
                border: 2px solid #e5e7eb;
                border-radius: 8px;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                transition: all 0.3s ease;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            .zoom-btn:hover {
                background: #2563eb;
                color: white;
                border-color: #2563eb;
                transform: scale(1.1);
            }
            .zoom-btn:active {
                transform: scale(0.95);
            }
        `;
        document.head.appendChild(style);

        const mapContainer = campusMap.parentElement;
        mapContainer.style.position = 'relative';
        mapContainer.appendChild(zoomControls);

        // Zoom in
        document.getElementById('zoomIn').addEventListener('click', function() {
            if (scale < maxScale) {
                scale += scaleStep;
                campusMap.style.transform = `scale(${scale})`;
                campusMap.style.transition = 'transform 0.3s ease';
            }
        });

        // Zoom out
        document.getElementById('zoomOut').addEventListener('click', function() {
            if (scale > minScale) {
                scale -= scaleStep;
                campusMap.style.transform = `scale(${scale})`;
                campusMap.style.transition = 'transform 0.3s ease';
            }
        });

        // Reset zoom
        document.getElementById('zoomReset').addEventListener('click', function() {
            scale = 1;
            campusMap.style.transform = 'scale(1)';
            campusMap.style.transition = 'transform 0.3s ease';
        });
    }
});
