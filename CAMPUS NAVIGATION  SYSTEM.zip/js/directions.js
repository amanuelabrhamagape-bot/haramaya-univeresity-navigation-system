// ===== DIRECTIONS FUNCTIONALITY =====
document.addEventListener('DOMContentLoaded', function() {
    const directionsForm = document.getElementById('directionsForm');
    const fromLocation = document.getElementById('fromLocation');
    const toLocation = document.getElementById('toLocation');
    const swapButton = document.getElementById('swapLocations');
    const directionsResult = document.getElementById('directionsResult');
    const routeSummary = document.getElementById('routeSummary');
    const routeSteps = document.getElementById('routeSteps');
    const newRouteButton = document.getElementById('newRoute');

    // Check for URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const fromParam = urlParams.get('from');
    const toParam = urlParams.get('to');
    
    if (fromParam) fromLocation.value = fromParam;
    if (toParam) toLocation.value = toParam;
    
    // Auto-submit if both parameters are present
    if (fromParam && toParam) {
        setTimeout(() => {
            directionsForm.dispatchEvent(new Event('submit'));
        }, 500);
    }

    // Swap locations
    if (swapButton) {
        swapButton.addEventListener('click', function() {
            const temp = fromLocation.value;
            fromLocation.value = toLocation.value;
            toLocation.value = temp;
            
            // Add rotation animation
            this.style.transform = 'rotate(180deg)';
            setTimeout(() => {
                this.style.transform = 'rotate(0deg)';
            }, 300);
        });
    }

    // Form submission
    if (directionsForm) {
        directionsForm.addEventListener('submit', function(e) {
            e.preventDefault();

            const from = fromLocation.value;
            const to = toLocation.value;

            // Validation
            if (!from || !to) {
                alert('Please select both starting location and destination');
                return;
            }

            if (from === to) {
                alert('Starting location and destination cannot be the same');
                return;
            }

            // Generate and display directions
            generateDirections(from, to);
        });
    }

    // New route button
    if (newRouteButton) {
        newRouteButton.addEventListener('click', function() {
            directionsResult.style.display = 'none';
            directionsForm.parentElement.style.display = 'block';
            directionsForm.reset();
            
            // Smooth scroll to form
            directionsForm.scrollIntoView({ behavior: 'smooth', block: 'center' });
        });
    }

    // Quick route cards
    const routeCards = document.querySelectorAll('.route-card');
    routeCards.forEach(card => {
        card.addEventListener('click', function() {
            const from = this.getAttribute('data-from');
            const to = this.getAttribute('data-to');
            
            fromLocation.value = from;
            toLocation.value = to;
            
            // Scroll to form and submit
            directionsForm.scrollIntoView({ behavior: 'smooth', block: 'center' });
            setTimeout(() => {
                directionsForm.dispatchEvent(new Event('submit'));
            }, 500);
        });
    });

    function generateDirections(from, to) {
        // Get route data
        const route = getRoute(from, to);
        
        if (!route) {
            alert('Unable to generate directions for this route');
            return;
        }

        // Display summary
        routeSummary.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
                <div>
                    <h3 style="margin-bottom: 0.5rem; color: var(--dark-color);">
                        <i class="fas fa-map-marker-alt" style="color: #10b981;"></i> ${route.fromName}
                        <i class="fas fa-arrow-right" style="margin: 0 1rem; color: var(--primary-color);"></i>
                        <i class="fas fa-flag-checkered" style="color: #ef4444;"></i> ${route.toName}
                    </h3>
                    <p style="color: var(--text-color);">
                        <i class="fas fa-walking"></i> ${route.distance} 
                        <span style="margin: 0 1rem;">•</span>
                        <i class="fas fa-clock"></i> ${route.duration}
                    </p>
                </div>
                <div>
                    <span style="background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); 
                                 color: white; padding: 0.5rem 1rem; border-radius: 20px; font-weight: 600;">
                        ${route.steps.length} Steps
                    </span>
                </div>
            </div>
        `;

        // Display steps
        routeSteps.innerHTML = route.steps.map((step, index) => `
            <div class="route-step" style="animation: slideIn 0.5s ease ${index * 0.1}s both;">
                <div class="step-number">${index + 1}</div>
                <div class="step-content">
                    <p><strong>${step.instruction}</strong></p>
                    ${step.detail ? `<p style="color: var(--text-color); margin-top: 0.5rem;">${step.detail}</p>` : ''}
                    ${step.distance ? `<p style="color: #6b7280; font-size: 0.9rem; margin-top: 0.5rem;">
                        <i class="fas fa-ruler"></i> ${step.distance}
                    </p>` : ''}
                </div>
            </div>
        `).join('');

        // Add arrival step
        routeSteps.innerHTML += `
            <div class="route-step" style="border-left-color: #10b981; background: #d1fae5; animation: slideIn 0.5s ease ${route.steps.length * 0.1}s both;">
                <div class="step-number" style="background: #10b981;">
                    <i class="fas fa-check"></i>
                </div>
                <div class="step-content">
                    <p><strong>You have arrived at ${route.toName}!</strong></p>
                </div>
            </div>
        `;

        // Hide form and show result
        directionsForm.parentElement.style.display = 'none';
        directionsResult.style.display = 'block';
        
        // Smooth scroll to result
        directionsResult.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function getRoute(from, to) {
        // Campus Route database with detailed walking directions
        const routes = {
            'library-cafeteria': {
                fromName: 'Library',
                toName: 'Cafeteria',
                distance: '350 meters',
                duration: '4-5 minutes',
                steps: [
                    { instruction: 'Exit the Library through the main entrance', detail: 'Head towards the central campus walkway' },
                    { instruction: 'Turn right and walk along the main path', detail: 'Pass by the student center', distance: '200m' },
                    { instruction: 'Continue straight towards the Cafeteria', detail: 'The building will be on your right', distance: '100m' },
                    { instruction: 'Enter the Cafeteria main entrance', detail: 'Dining hall is on the ground floor', distance: '50m' }
                ]
            },
            'cafeteria-library': {
                fromName: 'Cafeteria',
                toName: 'Library',
                distance: '350 meters',
                duration: '4-5 minutes',
                steps: [
                    { instruction: 'Exit the Cafeteria main entrance', detail: 'Turn left onto the main walkway' },
                    { instruction: 'Walk straight along the central path', detail: 'Keep the student center on your left', distance: '200m' },
                    { instruction: 'Continue towards the Library building', detail: 'The blue building will be visible ahead', distance: '100m' },
                    { instruction: 'Enter the Library main entrance', detail: 'Security check at entrance', distance: '50m' }
                ]
            },
            'dorms-library': {
                fromName: 'Dormitories',
                toName: 'Library',
                distance: '450 meters',
                duration: '5-6 minutes',
                steps: [
                    { instruction: 'Exit the Dormitory complex', detail: 'Use the main gate exit' },
                    { instruction: 'Turn right onto the residential road', detail: 'Head towards the main campus', distance: '200m' },
                    { instruction: 'Turn left at the main intersection', detail: 'You\'ll see the library ahead', distance: '150m' },
                    { instruction: 'Walk straight to the Library', detail: 'Main entrance with security desk', distance: '100m' }
                ]
            },
            'library-dorms': {
                fromName: 'Library',
                toName: 'Dormitories',
                distance: '450 meters',
                duration: '5-6 minutes',
                steps: [
                    { instruction: 'Exit the Library main entrance', detail: 'Turn left after exiting' },
                    { instruction: 'Walk to the main intersection', detail: 'Head towards the residential area', distance: '150m' },
                    { instruction: 'Turn right at the intersection', detail: 'Follow the residential road', distance: '200m' },
                    { instruction: 'Enter the Dormitory complex', detail: 'Main gate with security', distance: '100m' }
                ]
            },
            'admin-labs': {
                fromName: 'Administration Building',
                toName: 'Science Labs',
                distance: '400 meters',
                duration: '5-6 minutes',
                steps: [
                    { instruction: 'Exit the Administration Building', detail: 'Use the east exit' },
                    { instruction: 'Walk straight towards the Science Building', detail: 'Follow the main pathway', distance: '250m' },
                    { instruction: 'Continue to the Science Labs', detail: 'The building will be visible ahead', distance: '100m' },
                    { instruction: 'Enter the Science Labs building', detail: 'Main entrance with reception', distance: '50m' }
                ]
            },
            'labs-admin': {
                fromName: 'Science Labs',
                toName: 'Administration Building',
                distance: '400 meters',
                duration: '5-6 minutes',
                steps: [
                    { instruction: 'Exit the Science Labs building', detail: 'Use the main entrance' },
                    { instruction: 'Walk west towards the central campus', detail: 'Head towards the purple building', distance: '250m' },
                    { instruction: 'Continue to the Administration Building', detail: 'The building will be on your left', distance: '100m' },
                    { instruction: 'Enter the Administration Building', detail: 'Main entrance with reception desk', distance: '50m' }
                ]
            },
            'cafeteria-dorms': {
                fromName: 'Cafeteria',
                toName: 'Dormitories',
                distance: '300 meters',
                duration: '3-4 minutes',
                steps: [
                    { instruction: 'Exit the Cafeteria', detail: 'Turn left after exiting' },
                    { instruction: 'Walk south on the main path', detail: 'Head towards the residential area', distance: '150m' },
                    { instruction: 'Turn left onto the residential road', detail: 'Dormitories ahead', distance: '100m' },
                    { instruction: 'Enter the Dormitory complex', detail: 'Main gate entrance', distance: '50m' }
                ]
            },
            'dorms-cafeteria': {
                fromName: 'Dormitories',
                toName: 'Cafeteria',
                distance: '300 meters',
                duration: '3-4 minutes',
                steps: [
                    { instruction: 'Exit the Dormitory complex', detail: 'Turn right onto residential road' },
                    { instruction: 'Walk to the main campus path', detail: 'Turn right at intersection', distance: '100m' },
                    { instruction: 'Continue north on the main path', detail: 'Cafeteria will be on your left', distance: '150m' },
                    { instruction: 'Enter the Cafeteria', detail: 'Main entrance with dining hall', distance: '50m' }
                ]
            },
            'library-admin': {
                fromName: 'Library',
                toName: 'Administration Building',
                distance: '250 meters',
                duration: '3 minutes',
                steps: [
                    { instruction: 'Exit the Library main entrance', detail: 'Turn right onto main walkway' },
                    { instruction: 'Walk straight towards the Admin Building', detail: 'The purple building ahead', distance: '200m' },
                    { instruction: 'Enter the Administration Building', detail: 'Main entrance with reception', distance: '50m' }
                ]
            },
            'admin-library': {
                fromName: 'Administration Building',
                toName: 'Library',
                distance: '250 meters',
                duration: '3 minutes',
                steps: [
                    { instruction: 'Exit the Administration Building', detail: 'Turn left onto main walkway' },
                    { instruction: 'Walk straight towards the Library', detail: 'The blue building ahead', distance: '200m' },
                    { instruction: 'Enter the Library main entrance', detail: 'Security check at entrance', distance: '50m' }
                ]
            },
            'labs-cafeteria': {
                fromName: 'Science Labs',
                toName: 'Cafeteria',
                distance: '500 meters',
                duration: '6-7 minutes',
                steps: [
                    { instruction: 'Exit the Science Labs building', detail: 'Turn left onto main path' },
                    { instruction: 'Walk west towards central campus', detail: 'Pass by the Admin Building', distance: '300m' },
                    { instruction: 'Continue towards the Cafeteria', detail: 'The building will be on your left', distance: '150m' },
                    { instruction: 'Enter the Cafeteria main entrance', detail: 'Dining hall entrance', distance: '50m' }
                ]
            },
            'cafeteria-labs': {
                fromName: 'Cafeteria',
                toName: 'Science Labs',
                distance: '500 meters',
                duration: '6-7 minutes',
                steps: [
                    { instruction: 'Exit the Cafeteria', detail: 'Turn right onto main path' },
                    { instruction: 'Walk east towards the Science Building', detail: 'Pass by the Admin Building', distance: '300m' },
                    { instruction: 'Continue to the Science Labs', detail: 'The building will be visible ahead', distance: '150m' },
                    { instruction: 'Enter the Science Labs building', detail: 'Main entrance', distance: '50m' }
                ]
            }
        };

        // Try both directions
        const routeKey = `${from}-${to}`;
        if (routes[routeKey]) {
            return routes[routeKey];
        }

        // Generate generic route if specific route not found
        return generateGenericRoute(from, to);
    }

    function generateGenericRoute(from, to) {
        const locationNames = {
            'library': 'Library',
            'cafeteria': 'Cafeteria',
            'admin': 'Administration Building',
            'dorms': 'Dormitories',
            'labs': 'Science Labs'
        };

        return {
            fromName: locationNames[from] || from,
            toName: locationNames[to] || to,
            distance: '400 meters',
            duration: '5 minutes',
            steps: [
                { instruction: `Exit the ${locationNames[from]}`, detail: 'Head towards the main campus walkway' },
                { instruction: 'Follow the main pathway', detail: 'Look for directional signs', distance: '200m' },
                { instruction: `Head towards the ${locationNames[to]}`, detail: 'The building will be visible ahead', distance: '150m' },
                { instruction: `Enter the ${locationNames[to]}`, detail: 'Use the main entrance', distance: '50m' }
            ]
        };
    }
});

// ===== SLIDE IN ANIMATION =====
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateX(-30px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
`;
document.head.appendChild(style);
